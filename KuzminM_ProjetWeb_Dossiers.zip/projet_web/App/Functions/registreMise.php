<?php

namespace App\Controllers;

use \App\Models\Mise as model;


//$prixMise = $_COOKIE['prixMise'];
//$somevar = $_GET["prixMise"];
print_r($_REQUEST);
print_r($_POST);

?>